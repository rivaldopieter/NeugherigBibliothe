from nblibiothek.ui import *

if __name__ == '__main__':
    host = "localhost"
    user = "root"
    password = ""
    db = "PeminjamanBuku3"
    conn = AppDatabase(host, user, password, db)
    service = AppService(conn)
    gui = AppUI("Neugierig Bibliothek", "640x650", service)
